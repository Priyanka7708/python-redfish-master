============
Installation
============

At the command line::

    $ pip install python-redfish

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv python-redfish
    $ pip install python-redfish
