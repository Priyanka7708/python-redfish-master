========
Usage
========

To use python-redfish in a project::

    import redfish
